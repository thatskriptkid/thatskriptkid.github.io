var config = {
    'zh': {
        p1: '网络连接异常',
        p2: '请确认连接网络后重试',
        p3: '加载出错',
        p4: '点击重新加载'
    },
    'zh_tw': {
        p1: '網路異常',
        p2: '請檢查網路連線後重試',
        p3: '加載失敗',
        p4: '點擊重新加載'
    },
    'en': {
        p1: 'Network error',
        p2: 'Please check network and try again',
        p3: 'Load failed',
        p4: 'Tap to reload'
    },
    'ar': {
        p1: 'خطأ في الشبكة، يرجى المحاولة مرة أخرى في وقت لاحق',
        p2: 'من فضلك افصح شبكه الانترنت وحاول مره اخري',
        p3: 'فشل التحميل',
        p4: 'إعادة التحميل'
    },
    'de': {
        p1: 'Netzwerkfehler',
        p2: 'Bitte Netzwerk prüfen und erneut versuchen.',
        p3: 'Laden fehlgeschlagen',
        p4: 'Tippen, um neu zu laden'
    },
    'es': {
        p1: 'Error de la red',
        p2: 'Compruebe la red e inténtelo de nuevo',
        p3: 'Carga fallida',
        p4: 'Pulse para recargar'
    },
    'fr': {
        p1: 'Erreur de réseau',
        p2: 'Veuillez vérifier le réseau et recommencez',
        p3: 'Échec du chargement',
        p4: 'Touchez pour recharger'
    },
    'hi': {
        p1: 'नेटवर्क त्रुटि',
        p2: 'कृपया नेटवर्क जांचें और फिर कोशिश करें',
        p3: 'लोड करना विफल',
        p4: 'रीलोड हेतु टैप करें'
    },
    'id': {
        p1: 'Galat jaringan',
        p2: 'Mohon periksa jaringan dan coba lagi',
        p3: 'Gagal memuat',
        p4: 'Ketuk untuk memuat ulang'
    },
    'in': {
        p1: 'Galat jaringan',
        p2: 'Mohon periksa jaringan dan coba lagi',
        p3: 'Gagal memuat',
        p4: 'Ketuk untuk memuat ulang'
    },
    'ja': {
        p1: 'ネットワークエラー',
        p2: 'ネットワークを確認してからもう一度やり直してください',
        p3: '読み込みに失敗しました',
        p4: 'タップしてリロードします'
    },
    'ko': {
        p1: '네트워크 오류',
        p2: '네트워크를 확인하고 다시 시도하세요',
        p3: '로드 실패',
        p4: '다시 로드 하려면 누르세요'
    },
    'pt': {
        p1: 'Erro na rede',
        p2: 'Por favor, verifique a rede e tente novamente',
        p3: 'Falha ao carregar',
        p4: 'Toque para carregar novamente'
    },
    'ru': {
        p1: 'Ошибка сети',
        p2: 'Проверьте подключение к сети и попробуйте снова',
        p3: 'Ошибка загрузки',
        p4: 'Перезагрузка'
    },
    'th': {
        p1: 'เครือข่ายเกิดข้อผิดพลาด',
        p2: 'โปรดตรวจสอบเครือข่ายและลองอีกครั้ง',
        p3: 'การโหลดล้มเหลว',
        p4: 'แตะเพื่อโหลดใหม่'
    },
    'tr': {
        p1: 'Ağ hatası',
        p2: 'Lütfen ağ bağlantısını kontrol edip tekrar deneyin',
        p3: 'Yükleme başarısız',
        p4: 'Yeniden yüklemek için dokunun'
    }
}
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return 'en';
}
function getPrompt(lan) {
    var prompt = config['en'];
    for (var c in config) {
        if (c == lan) {
            prompt = config[c];
            break;
        }
    }
    return prompt;
}
function $(id) {
    return document.getElementById(id);
}
var lan = getQueryString('lan').toLocaleLowerCase();
var prompt = getPrompt(lan);
var p1 = prompt.p1, p2 = prompt.p2, p3 = prompt.p3, p4 = prompt.p4;
if ($('p1')) {
    $('p1').innerHTML = p1;
    $('p2').innerHTML = p2;
    $('p3').innerHTML = p1;
}
else {
    $('p2').innerHTML = p3;
    $('p3').innerHTML = p3;
    $('p4').innerHTML = p4;
}